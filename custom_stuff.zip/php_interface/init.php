<?php
defined('B_PROLOG_INCLUDED') || die;

require(__DIR__ . '/example/deferred.php');
require(__DIR__ . '/example/customuf.php');
require(__DIR__ . '/example/js.php');
