<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['CUSTOM_STUFF_HELLO_WORLD'] = 'Привет, Мир!';
$MESS['CUSTOM_STUFF_THANK_BUTTON'] = 'Поблагодарить сотрудника';
$MESS['CUSTOM_STUFF_POPUP_TITLE'] = 'Поблагодарить сотрудника';
$MESS['CUSTOM_STUFF_POPUP_DESCR'] = 'Введите текст благодарности.';
$MESS['CUSTOM_STUFF_POPUP_BUTTON'] = 'Отправить ген. директору';
$MESS['CUSTOM_STUFF_SHARE_CONFIRMATION'] = 'Политика компании запрещает публикацию секретных документов. Вы готовы подписаться кровью, что этот документ не секретный?';
$MESS['CUSTOM_STUFF_POPUP_BUTTON_YES'] = 'Да';
$MESS['CUSTOM_STUFF_POPUP_BUTTON_NO'] = 'Нет';
$MESS['CUSTOM_STUFF_SHARE_CONFIRMATION_TITLE'] = 'Публичная ссылка на документ';
$MESS['CUSTOM_STUFF_GROUP_CREATE_CONFIRMATION_TITLE'] = 'Создание группы';
$MESS['CUSTOM_STUFF_GROUP_CREATE_CONFIRMATION'] = 'Согласно политике компании вы обязаны следить за порядком в группе. Вы уверены, что хотите создать группу?';