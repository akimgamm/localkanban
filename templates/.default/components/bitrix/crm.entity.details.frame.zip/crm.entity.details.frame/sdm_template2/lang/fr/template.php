<?
$MESS["CRM_ENT_DETAIL_FRAME_COMPONENT_NOT_DEFINED"] = "Impossible de trouver le composant approprié pour afficher les entités \"#TYPE_NAME#\".";
?>