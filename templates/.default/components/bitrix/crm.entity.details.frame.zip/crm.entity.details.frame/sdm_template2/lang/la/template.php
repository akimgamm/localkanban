<?
$MESS["CRM_ENT_DETAIL_FRAME_COMPONENT_NOT_DEFINED"] = "No se puede encontrar el componente apropiado para mostrar \"#TYPE_NAME#\" las entidades.";
?>