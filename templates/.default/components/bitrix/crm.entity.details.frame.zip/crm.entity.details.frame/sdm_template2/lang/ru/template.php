<?
$MESS['CRM_ENT_DETAIL_FRAME_COMPONENT_NOT_DEFINED'] = "Не определён компонент для отображения элементов типа \"#TYPE_NAME#\".";