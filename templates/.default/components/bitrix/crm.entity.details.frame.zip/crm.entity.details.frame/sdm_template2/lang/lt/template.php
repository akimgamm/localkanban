<?
$MESS["CRM_ENT_DETAIL_FRAME_COMPONENT_NOT_DEFINED"] = "Nepavyko rasti tinkamo komponento rodyti \"#TYPE_NAME#\" įrašus.";
?>