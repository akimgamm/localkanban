<?
$MESS["CRM_ENT_DETAIL_FRAME_COMPONENT_NOT_DEFINED"] = "Nie można znaleźć odpowiedniego komponentu, aby wyświetlić w elementach \"#TYPE_NAME#\".";
?>