<?
$MESS["CRM_ENT_DETAIL_FRAME_COMPONENT_NOT_DEFINED"] = "Keine Komponente gefunden, um die Elemente \"#TYPE_NAME#\" anzuzeigen.";
?>