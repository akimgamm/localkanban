<?
$MESS["CRM_ENT_DETAIL_FRAME_COMPONENT_NOT_DEFINED"] = "Não é possível encontrar o componente adequado para mostrar entidades \"#TYPE_NAME#\".";
?>