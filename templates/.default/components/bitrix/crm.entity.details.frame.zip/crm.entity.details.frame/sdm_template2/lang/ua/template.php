<?
$MESS["CRM_ENT_DETAIL_FRAME_COMPONENT_NOT_DEFINED"] = "Не визначений компонент для відображення елементів типу \"#TYPE_NAME#\".";
?>