<?
$MESS["CRM_ENT_DETAIL_FRAME_COMPONENT_NOT_DEFINED"] = "Cannot find appropriate component to show \"#TYPE_NAME#\" entities.";
?>