<?

function bHook($hookParams, $hook)
{

  $queryData = http_build_query($hookParams);

  $queryUrl = $hook;
  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_SSL_VERIFYPEER => 0,
    // CURLOPT_GET => 1,
    CURLOPT_HEADER => 0,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $queryUrl,
    CURLOPT_POSTFIELDS => $queryData,
  ));

  $result = curl_exec($curl);
  curl_close($curl);
  return json_decode($result, 1);
  // return $result;
}
// }

//$inf = bHook([], "https://dstural24.ru/rest/830/l7bann8u7zjtvy8v/user.current.json");

$APPLICATION->SetTitle("Title114");


// $dp = CIntranetUtils::GetDeparmentsTree($section_id = 0, $bFlat = false);
echo "<pre>";
// print_r($dpdd);
echo "</pre>";


?>
12
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://dstinfo.ru/breaks/bitrixApps/Kanban/css/style.css">
  <title>Document</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <!-- <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400&display=swap" rel="stylesheet"> -->
</head>

<body>
  <div id="main"></div>

  <!-- <a href="https://dstural24.ru/company/personal/user/830/tasks/task/view/80187/">Задача</a> -->
  <!-- <textarea name="" id="" cols="30" rows="10">akt</textarea> -->
  <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
  <script src="https://dstinfo.ru/breaks/bitrixApps/Kanban/js/main.js"></script>

  <script>
    document.addEventListener("DOMContentLoaded", function(event) {
      console.log("DOM fully loaded and parsed");
      app.run();

      let stageProj = document.getElementsByClassName('stage' + '1' + '-project' + '209');
      console.log('111111111111111111111111111111111111111111111');
      console.log(stageProj);

    });
  </script>
</body>

</html>