<?
echo file_get_contents("index2.php");

?>

