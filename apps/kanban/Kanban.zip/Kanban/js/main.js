
function application() { };
app = new application();

application.prototype.bitrixHook = async function (params, hook) {
  var str = jQuery.param(params);
  // console.log(str);


  let response = await fetch(hook + "?" + str)
  response = await response.json();

  return response.result;
}

application.prototype.sortObjectByName = function (o) {
  var sorted = {},
    key, a = [];

  for (key in o) {
    if (o.hasOwnProperty(key)) {
      a.push(key);
    }
  }

  a.sort();

  for (key = 0; key < a.length; key++) {
    sorted[a[key]] = o[a[key]];
  }
  return sorted;
}


class UpView {
  constructor() {
    this.allStages = {};
    this.main = document.getElementById('main');

  }

  async getAllTasks() {
    let params = {
      filter: { "GROUP_ID": [209, 210] }, //Массив групп
    }

    let tasks = await app.bitrixHook(params, "https://dstural24.ru/rest/830/l7bann8u7zjtvy8v/tasks.task.list.json");
    tasks = tasks.tasks;//

    this.taskList = tasks;
  }

  async getAllStages() {
    let params = {
      "entityId": 209, //Массив групп
    }
    this.stages = await app.bitrixHook(params, "https://dstural24.ru/rest/830/l7bann8u7zjtvy8v/task.stages.get.json");

  }



  async printAllStages() { //Отрисовка вёрстки канбана: колонки и названия колодцев

    // this.main.style.height();

    let divStages = document.createElement('div'); //Название колодца
    divStages.classList.add('stages');
    divStages.setAttribute('id', 'stages');
    this.main.appendChild(divStages);


    let i = 0;
    for (const [key, stage] of Object.entries(this.stages)) {
      // console.log(key, stage);


      let svgStageTriangle = `<svg xmlns="http://www.w3.org/2000/svg" width="13" height="32" viewBox="0 0 13 32"><path fill="#${stage.COLOR}" fill-opacity="1" d="M0 0h3c2.8 0 4 3 4 3l6 13-6 13s-1.06 3-4 3H0V0z"/></svg>`
      let divSvgStageTriangle = document.createElement('div'); //Колонка
      divSvgStageTriangle.classList.add('svgStageTriangle');
      divSvgStageTriangle.innerHTML += svgStageTriangle;

      let divStage = document.createElement('div'); //Колонка
      divStage.classList.add('stage');
      // divStage.style.height(this.main.style.height+'40px');
      divStage.setAttribute('id', 'stage' + i);
      divStages.appendChild(divStage);


      let divStageName = document.createElement('div'); //Название колодца
      divStageName.classList.add('stageName');
      divStageName.setAttribute('id', 'stage-name' + i);
      divStageName.style.background = '#' + stage.COLOR;
      divStageName.textContent = stage.TITLE;

      let divStageSign = document.createElement('div'); //Название колодца
      divStageSign.classList.add('stageSign');

      divStage.appendChild(divStageSign);
      divStageSign.appendChild(divStageName);
      divStageSign.appendChild(divSvgStageTriangle);
      // divStage.appendChild(divStageTriangle);

      let divTaskList = document.createElement('div'); //Название колодца
      divTaskList.classList.add('stageTaskList');
      divTaskList.setAttribute('id', 'stage-tasklist' + i);
      divStage.appendChild(divTaskList);




      i++;
    }







    // for (const [key, deps] of Object.entries(this.final)) {
    //   console.log(key, deps);

    //   var divStage = document.createElement('div');
    //   divStage.style.cssText = 'width:350px;height:100%; display:inline-block; border: 1px dashed #444; vertical-align: middle';

    //   elemDiv.appendChild(divStage);
    //   var divDepName = document.createElement('div');

    //   deps.forEach(task => {
    //     console.log(deps);

    //     let departments = Object.values(deps);

    //     // console.log(Object.values(deps)[0]);

    //     departments.forEach(element => {
    //       let depName = Object.keys(element)[0];
    //       let depsTasks = Object.values(element)[0];
    //       divStage.appendChild(divDepName);
    //       divDepName.innerHTML = depName;
    //       divDepName.style.cssText = 'padding: 10px 5px; margin: 10px 0 10px 10px; border: 1px solid #e3e3e3';

    //       console.log(depName);
    //       console.log(depsTasks);

    //       depsTasks.forEach(task => {
    //         var divTask = document.createElement('div');
    //         divTask.setAttribute('id', task.id);
    //         divTask.style.cssText = 'box-shadow: 0px 2px 8px 0px rgba(34, 60, 80, 0.2); border-radius: 2px; margin: 10px 0 10px 10px; width:330px;height:100px; display:inline-block; border: 1px solid #F5FFFA; vertical-align: middle';
    //         var divTaskName = document.createElement('div');
    //         divTaskName.innerHTML = task.title;

    //         divStage.appendChild(divTask);

    //         // divTask = document.getElementById(task.id);
    //         divTask.appendChild(divTaskName);
    //         console.log(divTaskName);





    //         // divTask.innerHTML = '';


    //         // divTask.innerHTML += task.title;



    //       });

    //       //depsTasks

    //     });


    //   });
    // }


  }

  async addDepSigns() {
    let divDepSigns = document.createElement('div'); //Колонка
    divDepSigns.classList.add('department-signs');
    // divStage.style.height(this.main.style.height+'40px');
    divDepSigns.setAttribute('id', 'department-signs');
    this.main.appendChild(divDepSigns);
  }

  async addProjectSigns() {
    let divProjectSigns = document.createElement('div'); //Колонка
    divProjectSigns.classList.add('project-signs');
    // divStage.style.height(this.main.style.height+'40px');
    divProjectSigns.setAttribute('id', 'project-signs');
    this.main.appendChild(divProjectSigns);
  }

  async putUsers(params, task) {
    let user = await app.bitrixHook(params, "https://dstural24.ru/rest/830/l7bann8u7zjtvy8v/user.get.json");
    task.user = {};
    task.user.info = user[0]; //Подробная информация по пользователю записывается в задачу
    // console.log(user);
    return user;
  }

  async setUsers() {
    // params = {"id": arr.tasks[0].responsible.id };

    await Promise.all(this.taskList.map(function (task, i) { //Для всех задач
      return new Promise(function (resolve) {
        let params = { "id": task.responsible.id };
        resolve(this.putUsers(params, task));

      }.bind(this))
    }.bind(this)));


    // this.arr = [].concat.apply([], this.arr)

  }


  async putDeps(params, task) {
    let depName = await app.bitrixHook(params, "https://dstural24.ru/rest/830/l7bann8u7zjtvy8v/department.get.json");
    task.user.department = depName[0];
    // task.user.dep = '123';
    // console.log(depName);
  }

  async setDeps() {

    await Promise.all(this.taskList.map(function (task, i) { //Для всех задач
      return new Promise(function (resolve) {
        let params = { "id": task.user.info.UF_DEPARTMENT[0] };

        resolve(this.putDeps(params, task));

      }.bind(this))
    }.bind(this)));

  }


  async upViewProjectFilter() {
    const filteredTasks = this.taskList.reduce((acc, task, i) => {
      // Group initialization
      // if (!acc[task.group.name]) {
      //   acc[task.group.name] = [];
      // }

      // Grouping

      let departmentName = task.user.department.NAME;
      let departmentID = task.user.department.ID;

      if (!acc[task.groupId]) {
        acc[task.groupId] = {};
      }

      if (!acc[task.groupId].departments) {
        acc[task.groupId].departments = {};

      }

      if (!acc[task.groupId].departments[departmentID]) {
        acc[task.groupId].departments[departmentID] = {};
      }

      if (!acc[task.groupId].departments[departmentID].tasks) {
        acc[task.groupId].departments[departmentID].tasks = [];
      }




      // if (!acc[task.groupId][task.user.department.NAME]) {
      //   acc[task.groupId].departmentName = [];
      // }



      acc[task.groupId].departments[departmentID].tasks.push(task);
      acc[task.groupId].departments[departmentID].title = departmentName;
      // acc[task.groupId][departmentID].index = departmentName;
      acc[task.groupId].title = task.group.name;
      acc[task.groupId].id = task.groupId;
      // acc[task.group.name].push(task);


      return acc;
    }, {});

    this.filteredTasks = filteredTasks;

    console.log(Object.values(filteredTasks));

  }

  async upViewStagesFilter() {

    let stages = Object.values(this.stages);

    Object.values(this.filteredTasks).forEach(project => {
      project.m = [];

      project.maxStageLength = []; //Максимальная длина стадии проекта


      Object.values(project.departments).forEach(department => {
        project.maxStageLength.push(department.tasks.length);
      });

      const reducer = (previousValue, currentValue) => previousValue + currentValue;

      const maxProjectTasksCount = project.maxStageLength.reduce(reducer);
      project.maxProjectTasksCount = maxProjectTasksCount;





      Object.values(project.departments).forEach(department => {
        // console.log(department,department.tasks);
        // department.tasks
        department.tasks.forEach(task => {
          // console.log(task);
          if(task.stageId == '0') {console.log('TASK','task', task); task.stageId = '3111'; }//Ошибка Stage0
          // console.log(task,this.allStages[task.stageId]);
          let stageTitle = this.allStages[task.stageId].TITLE;
          task.stageTitle = stageTitle;
          // console.log(task);


          if (!department.id) {
            department.id = task.user.department.ID;
          }

          if (!department.filteredStages) {
            department.filteredStages = [];
          }

      

          if (!department.filteredStages[task.stageTitle]) {
            department.filteredStages[task.stageTitle] = [];
          }


          department.filteredStages[task.stageTitle].push(task);

          // console.log(department);


        });

        stages.forEach((stage)=>{
          if (!department.filteredStages[stage.TITLE]) {
              department.filteredStages[stage.TITLE]
          
            // department.filteredStages[stage.TITLE] = {};
            // department.filteredStages[stage.TITLE].title = stage.TITLE
          } 
        })

        department.maxStageLength = []; //Максимальная длина стадии проекта

        console.log(department.filteredStages);


        Object.values(department.filteredStages).forEach(stageTasks => {
        
          department.maxStageLength.push(stageTasks.length);
        });

        const maxDepartmentTasksCount = Math.max.apply(null, department.maxStageLength);
        department.maxDepartmentTasksCount = maxDepartmentTasksCount;
        project.m.push(maxDepartmentTasksCount);

      })

      const m = project.m.reduce(reducer);
      project.maxC = m;

      // let t = app.sortObjectByName(project.departments);
     let newValues = Object.values(project.departments).sort(( a, b ) => {
      var nameA=a.title.toLowerCase(), nameB=b.title.toLowerCase()
      if (nameA < nameB) //сортируем строки по возрастанию
        return -1
      if (nameA > nameB)
        return 1
      return 0 // Никакой сортировки
      });

      project.departments = newValues;

      console.log(newValues);

      // console.log(project.departments);


      // let result = 





    });

    // Math.max.apply(null, [1,3,5,-1,8,0])



  }

  async downViewFilter() {
    const filteredTasks = this.taskList.reduce((acc, task) => {
      // Group initialization
      if (!acc[task.user.department[0].NAME]) {
        acc[task.user.department[0].NAME] = [];
      }

      // Grouping
      acc[task.user.department[0].NAME].push(task);

      return acc;
    }, {});

    this.filteredTasks = filteredTasks;
  }

  // async filterStages() {
  //   const filterStages = Object.values(this.stages).reduce((acc, stage) => {
  //     // Group initialization
  //     if (!acc[stage.TITLE]) {
  //       acc[stage.TITLE] = [];
  //     }

  //     // Grouping
  //     acc[stage.TITLE].push(stage);

  //     return acc;
  //   }, {});

  //   this.filterStages = filterStages;
  //   console.log(filterStages);
  // }

  async filterByStages() {
    const filteredTasks = this.taskList.reduce((acc, task) => {
      // Group initialization
      console.log(this.stages, task.stageId);

      let stageTitle = this.stages[task.stageId].TITLE;
      task.stageTitle = [];
      task.stageTitle.push(stageTitle);


      if (!acc[task.stageTitle[0]]) {
        acc[task.stageTitle[0]] = [];
      }

      acc[task.stageTitle[0]].push(task);

      //  console.log(this.stages[task.stageId].TITLE);

      // Grouping
      // acc[task.stageTitle].push(stageTitle);

      return acc;
    }, {});

    this.final = filteredTasks;
    console.log(filteredTasks);
  }

  async putStagesTitles(params) {
    let depName = await app.bitrixHook(params, "https://dstural24.ru/rest/830/l7bann8u7zjtvy8v/task.stages.get");
    this.allStages = Object.assign(this.allStages, depName);
  }

  async setStagesTitles() {


    await Promise.all(this.taskList.map(function (task, i) { //Для всех задач
      return new Promise(function (resolve) {
        let params = { "entityId": task.groupId };

        resolve(this.putStagesTitles(params));

      }.bind(this))
    }.bind(this)));
  }

  //Можно удалить
  // async f() {
  //   const filteredTasks = this.final['Система в работе'].reduce((acc, task, i) => {
  //     // Group initialization
  //     if (!acc[task.user.dep[0].NAME]) {
  //       acc[task.user.dep[0].NAME] = [];
  //     }

  //     // Grouping
  //     acc[task.user.dep[0].NAME].push(task);

  //     return acc;
  //   }, {});

  //   console.log(filteredTasks);
  //   this.final['Система в работе'] = [];
  //   this.final['Система в работе'].push(filteredTasks);

  //   const f = this.final['Задачи (Бэклог)'].reduce((acc, task, i) => {
  //     // Group initialization
  //     if (!acc[task.user.dep[0].NAME]) {
  //       acc[task.user.dep[0].NAME] = [];
  //     }

  //     // Grouping
  //     acc[task.user.dep[0].NAME].push(task);

  //     return acc;
  //   }, {});

  //   console.log(filteredTasks);
  //   this.final['Задачи (Бэклог)'] = [];
  //   this.final['Задачи (Бэклог)'].push(f);
  // }



  // async drawKanban() {

  //   this.f();




  //   var elemDiv = document.createElement('div');
  //   elemDiv.setAttribute('id', 'main');

  //   elemDiv.style.cssText = 'width:100%;height:100%; background: rgb(208, 247, 227, 0.1)';



  //   for (const [key, deps] of Object.entries(this.final)) {
  //     console.log(key, deps);

  //     var divStage = document.createElement('div');
  //     divStage.style.cssText = 'width:350px;height:100%; display:inline-block; border: 1px dashed #444; vertical-align: middle';

  //     elemDiv.appendChild(divStage);
  //     var divDepName = document.createElement('div');





  //     deps.forEach(task => {
  //       console.log(deps);

  //       let departments = Object.values(deps);

  //       // console.log(Object.values(deps)[0]);

  //       departments.forEach(element => {
  //         let depName = Object.keys(element)[0];
  //         let depsTasks = Object.values(element)[0];
  //         divStage.appendChild(divDepName);
  //         divDepName.innerHTML = depName;
  //         divDepName.style.cssText = 'padding: 10px 5px; margin: 10px 0 10px 10px; border: 1px solid #e3e3e3';

  //         console.log(depName);
  //         console.log(depsTasks);

  //         depsTasks.forEach(task => {
  //           var divTask = document.createElement('div');
  //           divTask.setAttribute('id', task.id);
  //           divTask.style.cssText = 'box-shadow: 0px 2px 8px 0px rgba(34, 60, 80, 0.2); border-radius: 2px; margin: 10px 0 10px 10px; width:330px;height:100px; display:inline-block; border: 1px solid #F5FFFA; vertical-align: middle';
  //           var divTaskName = document.createElement('div');
  //           divTaskName.innerHTML = task.title;

  //           divStage.appendChild(divTask);

  //           // divTask = document.getElementById(task.id);
  //           divTask.appendChild(divTaskName);
  //           console.log(divTaskName);





  //           // divTask.innerHTML = '';


  //           // divTask.innerHTML += task.title;



  //         });

  //         //depsTasks

  //       });


  //     });
  //   }

  //   document.body.appendChild(elemDiv);


  // }




  getKeyByValue(object, value) {

    let stageKey = Object.keys(object).find(key => object[key].TITLE === value);
    // const index = object.map(e => e.name).indexOf(stageKey);
    let stageIndex = Object.keys(object).indexOf(stageKey); //Индекс стадии сделки в основном наборе

    return stageIndex;


  }




  async drawKanban() {

    const projSigns = document.getElementById('project-signs');

    const main = document.getElementById('main');

    let stageTaskLists = document.getElementsByClassName('stageTaskList');
    console.log(stageTaskLists);





  


    Object.values(this.filteredTasks).forEach((project, i) => {

      for (let i = 0; i < stageTaskLists.length; i++) {
        //Это дублируется внизу
        var divStageProjectDepartments = document.createElement('div'); //Див проекта
        divStageProjectDepartments.classList.add('stage-project-departments');
        divStageProjectDepartments.setAttribute('id', 'project' + project.id);
        divStageProjectDepartments.classList.add('stage' + i + '-project' + project.id);
        stageTaskLists[i].appendChild(divStageProjectDepartments);

        let h = String(120) * project.maxC +"px"; //8*project.maxC+"px"

          divStageProjectDepartments.style.height = h;
        // alert(23);
      }
      let h3 = String(120)*project.maxC +'px'; //project.maxProjectTasksCount
      // alert(h3);

      var divProjectSigns = document.createElement('div'); //Ярлык проекта
      divProjectSigns.classList.add('project-sign');
      divProjectSigns.style.height = h3;
      projSigns.appendChild(divProjectSigns);

      let divProjHr = document.createElement('div'); //Ярлык отдела
      divProjHr.classList.add('project-hr');

      divProjHr.style.width = 1800;

    
      projSigns.appendChild(divProjHr);



      let ProjNameSignTitle = document.createElement('div'); //Ярлык отдела
      ProjNameSignTitle.classList.add('project-sign-title');
      // divDepNameSignTitle.style.width = h2; //Не нужно
      ProjNameSignTitle.textContent = project.title;

      let divDepHr = document.createElement('div'); //Ярлык отдела
      divDepHr.classList.add('department-hr');


      divProjectSigns.appendChild(ProjNameSignTitle);
      // const depSigns = document.getElementById('department-signs');

      // divDepHr.style.width = 1800;



      
   




      for (const [depID, department] of Object.entries(project.departments)) {
        // stageTitle
        // console.log(departments.filteredStages);

        console.log(depID,department);

        let depCount = 0;
        let filteredStages = department.filteredStages;

       let divDEP = document.createElement('div'); //Ярлык отдела
       let h6 = String(120) * department.maxDepartmentTasksCount + "px";
      divDEP.setAttribute('data-depar',department.id);

        divDEP.style.height = h6;
        divDEP.setAttribute('data-depar',department.id);

        // for (let i = 0; i < stageTaskLists.length; i++) {

        //   if() {
        //     stageTaskLists[i].appendChild(divDEP.cloneNode());

        //   } else {

        //   }
        // }
  

        // divStageProjectDepartments.appendChild(divDEP);


        for (const [stageTitle, tasks] of Object.entries(filteredStages)) {
          let stageIndex = this.getKeyByValue(this.stages, stageTitle);
          let stageTaskList = document.getElementById('stage-tasklist' + stageIndex);

          // const reducer = (previousValue, currentValue) => previousValue + currentValue;
          // const maxProjectTasksCount = project.maxStageLength.reduce(reducer);
          let stageProj = document.getElementsByClassName('stage' + stageIndex + '-project' + project.id);
          // let stageProj = Array.from(stageProjCollection);

          console.log(stageTaskList);
          if (stageProj.length<1) {

            //Эти комменты не надо
            // var divStageProjectDepartments = document.createElement('div'); //Див проекта
            // divStageProjectDepartments.classList.add('stage-project-departments');
            // divStageProjectDepartments.setAttribute('id', 'project' + project.id);
            // divStageProjectDepartments.classList.add('stage' + stageIndex + '-project' + project.id);
            // stageTaskList.appendChild(divStageProjectDepartments);



            // alert(divStageProjectDepartments);
          } else {
            var divStageProjectDepartments = stageProj[0];

            divStageProjectDepartments.classList.add('stage-project-departments');
            divStageProjectDepartments.setAttribute('id', 'project' + project.id);
            divStageProjectDepartments.classList.add('stage' + stageIndex + '-project' + project.id);
            stageTaskList.appendChild(divStageProjectDepartments);
            console.log(divStageProjectDepartments);
          }


          let h = String(120) * project.maxC +"px"; //8*project.maxC+"px"

          divStageProjectDepartments.style.height = h;
    


          

          let divDepartmentTasks = document.createElement('div'); //Набор задач по отделу в колодце
          divDepartmentTasks.classList.add('stage-department-tasks');
          divDepartmentTasks.classList.add('stage-department-tasks-st'+stageIndex+'-dep-'+ department.id);

 
          console.log(tasks);

          let divTaskCollection = [];
          tasks.forEach((task, i) => {
            let divTask = document.createElement('div'); //карточка задачи
            divTask.classList.add('task');

            // stageTaskList.appendChild(divTask);

            let divTaskColorBlock = document.createElement('div'); //Цветовой блок карточки
            divTaskColorBlock.classList.add('color-block');
            divTask.appendChild(divTaskColorBlock);


            let divTaskName = document.createElement('a'); //Название карточки
            divTaskName.setAttribute('href', 'https://dstural24.ru/workgroups/group/'+department.id+'/tasks/task/view/' + task.id + '/')
            divTaskName.classList.add('task-title');
            divTaskName.textContent = task.title.substring(0, 40) + "...";

        

            divTask.appendChild(divTaskName);

            divTaskCollection.push(divTask);
            // console.log(t)

            let h = String(120) * department.maxDepartmentTasksCount + "px";

            if (i == tasks.length - 1) {

              for (var i = 0; i < divTaskCollection.length; ++i) {
                divDepartmentTasks.appendChild(divTaskCollection[i]);
              }
              

       


              console.log(divDepartmentTasks);

              divDepartmentTasks.setAttribute('id', 'dep' + department.id);
              divDepartmentTasks.style.height = h;

              // divStageProjectDepartments.appendChild(divDepartmentTasks.cloneNode())

             
              // for(let i = 0; i < 5; i++ ) {
             
    

              if(depCount == Object.values(filteredStages).length-1) {
                let h2 = String(120) * department.maxDepartmentTasksCount + "px";
                let divDepNameSign = document.createElement('div'); //Ярлык отдела
                // divDepNameSign.setAttribute('id', 'https://dstural24.ru/workgroups/group/210/tasks/task/view/' + task.id + '/')
                divDepNameSign.classList.add('department-sign');
                // divTask.appendChild(divDepNameSign);
                divDepNameSign.style.height = h2;
                let divDepNameSignTitle = document.createElement('div'); //Ярлык отдела
                divDepNameSignTitle.classList.add('department-sign-title');
                divDepNameSignTitle.setAttribute('data-dep-id','dep'+department.id);
                
                // console.log(('dep'+department.id), divDepartmentTasks.getAttribute('id'))
                // if('dep'+department.id == divDepartmentTasks.getAttribute('id')) {
                //   divStageProjectDepartments.appendChild(divDepartmentTasks);

                // } else {
                //   let div = document.createElement('div'); //Ярлык отдела
                //   div.style.height = h2;
                //   divStageProjectDepartments.appendChild(div);
                //   alert(123)

                // }

                // divDepNameSignTitle.style.width = h2; //Не нужно
                divDepNameSignTitle.textContent = department.title.substring(0, 30) + "...";

                let divDepHr = document.createElement('div'); //Ярлык отдела
                divDepHr.classList.add('department-hr');


                divDepNameSign.appendChild(divDepNameSignTitle);
                const depSigns = document.getElementById('department-signs');

                const main = document.getElementById('main');
                divDepHr.style.width = 1800;

                depSigns.appendChild(divDepNameSign);
                depSigns.appendChild(divDepHr);

              }



              divStageProjectDepartments.appendChild(divDepartmentTasks);






            }



            // divTask.appendChild(divTaskName);

          });

          depCount++;


          let divDepName = document.createElement('div'); //Блок названия
          divDepName.classList.add('department-name');
          // stageTaskList.appendChild(divDepName);












        }




      }

    });
  }



}



application.prototype.animate = function () {

  const animateCSS = (element, animation, prefix = 'animate__') =>
    // We create a Promise and return it
    new Promise((resolve, reject) => {
      const animationName = `${prefix}${animation}`;
      const node = document.querySelector(element);

      node.style.setProperty('--animate-duration', '0.5s');

      node.classList.add(`${prefix}animated`, animationName);

      // When the animation ends, we clean the classes and resolve the Promise
      function handleAnimationEnd(event) {
        event.stopPropagation();
        node.classList.remove(`${prefix}animated`, animationName);
        resolve('Animation ended');
      }

      node.addEventListener('animationend', handleAnimationEnd, { once: true });
    });

  // animateCSS('.task', 'fadeInUp');

}

application.prototype.addGroup = async function () {

  let params = {
    'NAME': 'Web',
    'VISIBLE': 'Y',
    'OPENED': 'N',
    'INITIATE_PERMS': 'N'
  }

  let group = await app.bitrixHook(params, "https://dstural24.ru/rest/830/a31yf1u7rzxrr5jz/sonet_group.create.json");
  // alert('123');


}


application.prototype.run = async function () {

  let upView = new UpView();
  await upView.getAllStages(); //Получаем набор колонок с первой группы
  await upView.addProjectSigns(); //Проектов

  await upView.addDepSigns(); //Ярлыки подразделений
  await upView.printAllStages(); //Отрисовываем полученные колонки

  await upView.getAllTasks(); //Получаем список всех задач по всем группам


  await upView.setUsers();//Чтобы получить подразделение по каждой задаче, необходимо для начала получить пользователей
  await upView.setDeps(); //Записываем подразделение в задачу
  await upView.setStagesTitles(); //Все айдишники колонок со всех групп

  await upView.upViewProjectFilter();
  await upView.upViewStagesFilter();
  await upView.drawKanban();

  app.animate();

  // await upView.filterByStages();

  // await upView.drawKanban();

  // await upView.downViewFilter();

  console.log(upView);





}


