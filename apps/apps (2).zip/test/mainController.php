<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
//require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_after.php");
//require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
//require("https://dstinfo.ru/breaks/bitrixApps/Kanban/index2.php");
function bitrixHook($hookParams, $hook)
  {
    // $queryUrl = "https://akimgamm.bitrix24.ru/rest/1/dp2kh5h9icf317bj/". $method ;

    // $data = [
    //   "IBLOCK_TYPE_ID" => "lists",
    //   "IBLOCK_ID" => 72,
    //   "FILTER" => array(
    //     // "PROPERTY_249" => 2332
    //   )
    // ];


    $queryData = http_build_query($hookParams);

    $queryUrl = $hook;
    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_SSL_VERIFYPEER => 0,
      // CURLOPT_GET => 1,
		//CURLOPT_HEADER => 0,
      CURLOPT_RETURNTRANSFER => 1,
      CURLOPT_URL => $queryUrl,
      CURLOPT_POSTFIELDS => $queryData,
    ));

    $result = curl_exec($curl);
    curl_close($curl);
    // return json_decode($result, 1);
    return $result;
  }
// }

$inf = bitrixHook([],"https://dstinfo.ru/breaks/bitrixApps/Kanban/index.php");

//print_r($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog.php")

file_put_contents('file.php', $inf);

?>

<?

$APPLICATION->IncludeFile($APPLICATION->GetCurDir()."file.php", Array(), Array(
	//"MODE" => "php",                                          

    ));


?>







<? //require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");

//require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_after.php");
//require_once($_SERVER['DOCUMENT_ROOT'] . "/bitrix/modules/main/include/prolog_before.php");
//require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/footer.php"
?>