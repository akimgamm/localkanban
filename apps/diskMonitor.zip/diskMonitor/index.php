<?

require_once (__DIR__.'/crest.php');

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Document");


// $res = CFile::GetList(array("FILE_SIZE"=>"desc"), array("MODULE_ID"=>"main"));
// while($res_arr = $res->GetNext())
//     echo $res_arr["SUBDIR"]."/".$res_arr["FILE_NAME"]." = ".$res_arr["FILE_SIZE"]."<br>";
// 
//$file = new IO\File(Application::getDocumentRoot();
//print_r($file);

$g = new CFile;

$k = $g->GetByID(57);
$k = $g->GetList(null,array("MODULE_ID"=>"disk"));
//$k = $g->GetList(null,null);

$res = [];
$z = 0;
echo "<pre>";
//print_r($k);
while($res_arr = $k->GetNext()) {

	if($res_arr['FILE_SIZE']>209715200) {
print_r($res_arr);
$z+=$res_arr['FILE_SIZE'];
echo "<br>";

echo "z=" .$z;
echo "<br>";
	}

}

print_r($res); 
	//echo $res_arr["SUBDIR"]."/".$res_arr["FILE_NAME"]." = ".$res_arr["FILE_SIZE"]."<br>";

echo "</pre>";


?><?
require($_SERVER['DOCUMENT_ROOT'] . "/bitrix/header.php");


?>






<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");
?>