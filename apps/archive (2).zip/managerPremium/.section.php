<?
$sSectionName="managerPremium";
?>