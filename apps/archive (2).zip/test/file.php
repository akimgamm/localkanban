<?
//header("Content-Type: text/plain; charset=UTF-8");
echo "123";


function bHook($hookParams, $hook)
{

  $queryData = http_build_query($hookParams);

  $queryUrl = $hook;
  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_SSL_VERIFYPEER => 0,
    // CURLOPT_GET => 1,
    CURLOPT_HEADER => 0,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => $queryUrl,
    CURLOPT_POSTFIELDS => $queryData,
  ));

  $result = curl_exec($curl);
  curl_close($curl);
  return json_decode($result, 1);
  // return $result;
}
// }

$inf = bHook([], "https://dstural24.ru/rest/830/l7bann8u7zjtvy8v/user.current.json");
// print_r($inf);

$APPLICATION->SetTitle("Title114");

$dp = CIntranetUtils::GetDeparmentsTree($section_id = 0, $bFlat = false);
echo "<pre>";
print_r($dp);
echo "</pre>";


// $APPLICATION->IncludeComponent(
//   "bitrix:intranet.structure",
//   "",
//   array(
//     "SHOW_FROM_ROOT" => "N",
//     "MAX_DEPTH" => "2",
//     "MAX_DEPTH_FIRST" => "0",
//     "COLUMNS" => "2",
//     "COLUMNS_FIRST" => "2",
//     "SHOW_SECTION_INFO" => "Y",
//     "USER_PROPERTY" => array("EMAIL", "PERSONAL_ICQ", "PERSONAL_PHONE", "PERSONAL_MOBILE", "UF_PHONE_INNER"),
//     "AJAX_MODE" => "Y",
//     "SEARCH_URL" => "search.php",
//     "PM_URL" => "/messages/form/#USER_ID#/",
//     "PATH_TO_CONPANY_DEPARTMENT" => "/company/structure.php?set_filter_structure=Y&structure_UF_DEPARTMENT=#ID#",
//     "FILTER_1C_USERS" => "Y",
//     "FILTER_NAME" => "users",
//     "USERS_PER_PAGE" => "10",
//     "FILTER_SECTION_CURONLY" => "Y",
//     "NAME_TEMPLATE" => "#NOBR##LAST_NAME# #NAME##/NOBR#",
//     "SHOW_LOGIN" => "Y",
//     "SHOW_ERROR_ON_NULL" => "Y",
//     "NAV_TITLE" => "Сотрудники",
//     "SHOW_NAV_TOP" => "Y",
//     "SHOW_NAV_BOTTOM" => "Y",
//     "SHOW_UNFILTERED_LIST" => "N",
//     "DATE_FORMAT" => "d-m-Y",
//     "DATE_FORMAT_NO_YEAR" => "d.m",
//     "DATE_TIME_FORMAT" => "d.m.Y H:i:s",
//     "SHOW_YEAR" => "Y",
//     "CACHE_TYPE" => "A",
//     "CACHE_TIME" => "3600",
//     "AJAX_OPTION_JUMP" => "N",
//     "AJAX_OPTION_STYLE" => "Y",
//     "AJAX_OPTION_HISTORY" => "N"
//   )
// );
//Asset::getInstance()->addJs("https://dstinfo.ru/breaks/bitrixApps/Kanban/js/main.js"); 
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>

  <textarea name="" id="" cols="30" rows="10">akt</textarea>
  <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
  <script src="https://dstinfo.ru/breaks/bitrixApps/Kanban/js/main.js"></script>
</body>

</html>
