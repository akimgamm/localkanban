<?
$sSectionName="test";
?>