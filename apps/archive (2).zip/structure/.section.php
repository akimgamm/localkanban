<?
$sSectionName="structure";
?>